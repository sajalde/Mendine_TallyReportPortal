﻿namespace ReportRDLC.Dataset
{


    public partial class ReportDataSet_Leadtime
    {
    }
}
